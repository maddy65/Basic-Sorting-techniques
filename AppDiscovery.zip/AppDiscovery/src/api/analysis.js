const { runDiscoveryPipeline, buildCanonicalGraph, buildExecutiveNarrative, buildBusinessUseCases } = require('../business-engine/business-engine');
const { analyzeSourceFiles, collectFiles } = require('../analyzers/source/source-code-analyzer');

function runAnalysis(options) {
  return runDiscoveryPipeline(options);
}

module.exports = {
  runAnalysis,
  runDiscoveryPipeline,
  buildCanonicalGraph,
  buildExecutiveNarrative,
  buildBusinessUseCases,
  analyzeSourceFiles,
  collectFiles,
};
