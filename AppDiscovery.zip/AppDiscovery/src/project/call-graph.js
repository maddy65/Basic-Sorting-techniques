const fs = require("fs");

class CallGraphBuilder {

    build(
        controllers,
        services
    ) {

        const graph = [];

        controllers.forEach(
            controller => {

                const content =
                    fs.readFileSync(
                        controller.file,
                        "utf8"
                    );

                services.forEach(
                    service => {

                        const serviceName =
                            service.name
                                .replace(
                                    ".cs",
                                    ""
                                )
                                .replace(
                                    ".java",
                                    ""
                                );

                        const regex =
                            new RegExp(
                                serviceName,
                                "i"
                            );

                        if (
                            regex.test(
                                content
                            )
                        ) {

                            graph.push({
                                from:
                                    controller.name,
                                to:
                                    service.name
                            });

                        }

                    }
                );

            }
        );

        return graph;
    }
}

module.exports =
    new CallGraphBuilder();