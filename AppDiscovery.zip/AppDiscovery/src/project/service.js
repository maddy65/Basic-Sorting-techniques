const fs = require("fs");

class ServiceExtractor {

    extract(files) {

        const services = [];

        files.forEach(file => {

            const name =
                file.split("/").pop();

            if (
                name.includes("Service")
            ) {

                const content =
                    fs.readFileSync(
                        file,
                        "utf8"
                    );

                const methods =
                    [
                        ...content.matchAll(
                            /public\s+.*?\s+(\w+)\s*\(/g
                        )
                    ].map(
                        x => x[1]
                    );

                services.push({
                    name,
                    methods,
                    file
                });
            }

        });

        return services;
    }
}

module.exports =
    new ServiceExtractor();