const scanner =
    require(
        "./project-scanner"
    );

const controllerExtractor =
    require(
        "./controller-extractor"
    );

const serviceExtractor =
    require(
        "./service-extractor"
    );

const graphBuilder =
    require(
        "./call-graph-builder"
    );

const files =
    await scanner.scan(
        "D:/backend"
    );

const controllers =
    controllerExtractor.extract(
        files
    );

const services =
    serviceExtractor.extract(
        files
    );

const graph =
    graphBuilder.build(
        controllers,
        services
    );

console.log(graph);