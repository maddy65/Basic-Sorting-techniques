const fs = require("fs");

class ControllerExtractor {

    extract(files) {

        const controllers = [];

        files.forEach(file => {

            const name =
                file.split("/").pop();

            if (
                name.includes("Controller")
            ) {

                const content =
                    fs.readFileSync(
                        file,
                        "utf8"
                    );

                const methods =
                    [
                        ...content.matchAll(
                            /public\s+.*?\s+(\w+)\s*\(/g
                        )
                    ].map(
                        x => x[1]
                    );

                controllers.push({
                    name,
                    methods,
                    file
                });
            }

        });

        return controllers;
    }
}

module.exports =
    new ControllerExtractor();