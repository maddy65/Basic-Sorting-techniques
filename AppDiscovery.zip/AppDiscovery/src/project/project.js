const fg = require("fast-glob");

class ProjectScanner {

    async scan(path) {

        const files = await fg(
            [
                `${path}/**/*.cs`,
                `${path}/**/*.java`,
                `${path}/**/*.js`,
                `${path}/**/*.ts`
            ],
            {
                absolute: true
            }
        );

        return files;
    }
}

module.exports = new ProjectScanner();