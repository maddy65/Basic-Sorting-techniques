const path = require('node:path');
const { analyzeRuntime } = require('../analyzers/runtime/playwright-runtime-analyzer');
const { analyzeSource } = require('../analyzers/source/source-code-analyzer');
const { buildCanonicalGraph } = require('../graph/graph-builder');
const { writeReports, buildExecutiveNarrative } = require('../reports/report-generator');
const { createLogger } = require('../utils/logger');

function normalizeText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function buildBusinessUseCases(runtimeData) {
  const useCases = [];
  const seen = new Set();

  const addUseCase = (entry) => {
    const key = `${entry.actor}:${entry.goal}`.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    useCases.push(entry);
  };

  const pageSignals = (runtimeData || []).map((page) => {
    const evidenceChunks = [
      page.title || '',
      ...(page.headings || []),
      page.text || '',
      ...(page.links || []).map((link) => link.text || ''),
      ...(page.forms || []).flatMap((form) => [...(form.labels || []), form.action || '']),
      ...(page.menus || []),
    ];

    const evidenceText = evidenceChunks.join(' ');
    return {
      page,
      evidenceText,
      normalizedText: normalizeText(evidenceText).toLowerCase(),
    };
  });

  const siteVocabulary = pageSignals.map((entry) => entry.evidenceText).join(' ').toLowerCase();

  const categories = [
    {
      actor: 'Customer',
      goal: 'Shop for products or services and move toward a purchase',
      businessValue: 'Help visitors discover products or services and move toward a decision.',
      keywords: ['shop', 'buy', 'product', 'catalog', 'pricing', 'plan', 'plans', 'order', 'offer', 'package', 'subscription', 'purchase', 'commerce', 'price', 'featured product', 'featured products'],
      steps: ['Open the main entry page', 'Review the available offers or plans', 'Select a product or package', 'Progress toward a purchase or inquiry'],
    },
    {
      actor: 'Prospect',
      goal: 'Contact the business or request support',
      businessValue: 'Turn interest into a tracked inquiry or support interaction.',
      keywords: ['contact', 'support', 'help', 'question', 'quote', 'request', 'inquiry', 'reach', 'consult', 'get in touch', 'talk to us'],
      steps: ['Find the contact or support entry point', 'Share the required details', 'Submit the request', 'Receive the follow-up or response'],
    },
    {
      actor: 'Registered User',
      goal: 'Sign in or manage an account',
      businessValue: 'Allow authenticated users to access personalised features and manage their profile.',
      keywords: ['sign in', 'login', 'register', 'account', 'profile', 'member', 'auth'],
      steps: ['Open the account or authentication entry point', 'Authenticate or create the account', 'Access the secure area', 'Manage account-related actions'],
    },
    {
      actor: 'Customer',
      goal: 'Start a free trial or book a demo',
      businessValue: 'Reduce friction for service scheduling and sales conversations.',
      keywords: ['book', 'appointment', 'schedule', 'reserve', 'calendar', 'demo', 'meeting', 'trial', 'free trial', 'consultation'],
      steps: ['Locate the scheduling or demo entry point', 'Choose the preferred date or option', 'Submit the request', 'Confirm the booking or follow-up'],
    },
    {
      actor: 'Visitor',
      goal: 'Navigate the site and discover major sections',
      businessValue: 'Make it easy for visitors to find relevant paths and content.',
      keywords: ['browse', 'explore', 'discover', 'navigation', 'menu', 'home', 'featured', 'latest', 'section', 'overview'],
      steps: ['Open the main navigation or landing experience', 'Browse the visible sections', 'Choose the section that matches the need', 'Continue the journey from the selected path'],
    },
    {
      actor: 'Visitor',
      goal: 'Learn about the company, services or portfolio',
      businessValue: 'Build trust and explain the organization’s value proposition.',
      keywords: ['about', 'company', 'story', 'mission', 'team', 'portfolio', 'service', 'services', 'solution', 'offering', 'who we are', 'our story'],
      steps: ['Open the company or service overview page', 'Review the key story and value proposition', 'Connect the information to the product or service', 'Use the insight to choose the next step'],
    },
    {
      actor: 'Visitor',
      goal: 'Consume articles, resources or educational content',
      businessValue: 'Support education, engagement and lead generation.',
      keywords: ['blog', 'article', 'news', 'resource', 'guide', 'whitepaper', 'download', 'media', 'library', 'learn more'],
      steps: ['Open the content or resource section', 'Review a relevant article or guide', 'Use the content to continue the journey', 'Move toward a next step such as inquiry or purchase'],
    },
    {
      actor: 'Candidate',
      goal: 'Explore careers or hiring opportunities',
      businessValue: 'Support talent attraction and recruitment.',
      keywords: ['career', 'hiring', 'job', 'apply', 'recruit'],
      steps: ['Open the careers or hiring area', 'Review the available opportunity', 'Select the relevant application path', 'Continue the application or contact journey'],
    },
    {
      actor: 'Participant',
      goal: 'Discover or join events or community activities',
      businessValue: 'Increase participation and engagement.',
      keywords: ['event', 'webinar', 'conference', 'workshop', 'community'],
      steps: ['Open the events or community area', 'Review the upcoming activity', 'Choose the event or session', 'Register or participate'],
    },
  ];

  categories.forEach((category) => {
    const matchedPages = pageSignals.filter((entry) => category.keywords.some((keyword) => entry.normalizedText.includes(keyword)));
    const matchedSiteVocabulary = category.keywords.some((keyword) => siteVocabulary.includes(keyword));
    if (matchedPages.length === 0 && !matchedSiteVocabulary) return;

    const evidence = Array.from(new Set(matchedPages.flatMap((entry) => {
      const pageEvidence = [entry.page.title || entry.page.url];
      const linkText = (entry.page.links || []).slice(0, 4).map((link) => link.text || '').filter(Boolean);
      return [...pageEvidence, ...linkText];
    })));

    const confidence = matchedPages.length >= 2 ? 'high' : 'medium';

    addUseCase({
      id: `UC${useCases.length + 1}`,
      actor: category.actor,
      goal: category.goal,
      businessValue: category.businessValue,
      steps: category.steps,
      evidence: evidence.slice(0, 8),
      scope: 'application',
      confidence,
    });
  });

  if (useCases.length === 0) {
    const firstPage = runtimeData[0] || {};
    addUseCase({
      id: 'UC1',
      actor: 'Visitor',
      goal: 'Explore the website and navigate to its major business areas',
      businessValue: 'Provide a clear entry point into the offering and support next-step discovery.',
      steps: ['Open the landing page', 'Review the visible navigation or content sections', 'Select a path that matches the user need', 'Continue the journey based on the selected action'],
      evidence: [firstPage.title || firstPage.url || 'Homepage'],
      scope: 'application',
      confidence: 'medium',
    });
  }

  return useCases;
}

async function runDiscoveryPipeline({
  appUrl,
  frontendPath,
  backendPath,
  outputDir = path.join(process.cwd(), 'reports'),
  logger = createLogger('business-engine'),
} = {}) {
  const runtimeData = await analyzeRuntime({ appUrl, outputDir, logger });
  const sourceAnalysis = await analyzeSource({ frontendPath, backendPath, logger });
  const graph = buildCanonicalGraph(runtimeData, sourceAnalysis);
  // infer a heuristic call graph from the source analysis when available
  try {
    const { inferCallGraphFromAnalysis } = require('../analyzers/source/source-code-analyzer');
    const callGraph = inferCallGraphFromAnalysis(sourceAnalysis);
    // attach to graph for downstream reporting
    graph.callGraph = callGraph;
  } catch (err) {
    logger.warn('Call-graph inference failed', { error: err.message });
  }
  const reportPaths = await writeReports(runtimeData, sourceAnalysis, graph, outputDir, logger);

  return {
    runtimeData,
    sourceAnalysis,
    graph,
    executiveNarrative: buildExecutiveNarrative(runtimeData, sourceAnalysis),
    reportPaths,
  };
}

async function main() {
  const [targetUrl, frontendPath, backendPath] = process.argv.slice(2);
  const result = await runDiscoveryPipeline({ appUrl: targetUrl, frontendPath, backendPath });
  console.log(JSON.stringify({ reportPaths: result.reportPaths, runtimePages: result.runtimeData.length, graphNodes: result.graph.nodes.length, graphEdges: result.graph.edges.length }, null, 2));
}

if (require.main === module) {
  main().catch((error) => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = {
  runDiscoveryPipeline,
  buildCanonicalGraph,
  buildExecutiveNarrative,
  buildBusinessUseCases,
};
