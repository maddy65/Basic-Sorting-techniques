const express = require('express');
const path = require('node:path');
const { runDiscoveryPipeline } = require('./business-engine/business-engine');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.post('/api/analyze', async (req, res) => {
  try {
    const { appUrl, frontendPath, backendPath } = req.body;
    const hasRuntimeInput = Boolean(appUrl);
    const hasSourceInput = Boolean(frontendPath || backendPath);

    if (!hasRuntimeInput && !hasSourceInput) {
      return res.status(400).json({ error: 'Please provide either a web app URL or at least one local source path.' });
    }

    const result = await runDiscoveryPipeline({
      appUrl: appUrl || null,
      frontendPath: frontendPath ? path.resolve(frontendPath) : null,
      backendPath: backendPath ? path.resolve(backendPath) : null,
    });

    res.json({
      success: true,
      runtimePages: result.runtimeData.length,
      reportPaths: result.reportPaths,
      executiveNarrative: result.executiveNarrative,
      sourceSummary: {
        controllers: result.sourceAnalysis.controllers.length,
        services: result.sourceAnalysis.services.length,
        repositories: result.sourceAnalysis.repositories.length,
        entities: result.sourceAnalysis.entities.length,
        apis: result.sourceAnalysis.apis.length,
        databaseTables: result.sourceAnalysis.databaseTables.length,
        integrations: result.sourceAnalysis.integrations.length,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Analysis failed.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Reverse engineering assistant running at http://localhost:${port}`);
});
