function createLogger(scope = 'appdiscovery') {
  const prefix = `[${scope}]`;
  return {
    info(message, meta) {
      if (meta) {
        console.log(prefix, message, JSON.stringify(meta));
      } else {
        console.log(prefix, message);
      }
    },
    warn(message, meta) {
      if (meta) {
        console.warn(prefix, message, JSON.stringify(meta));
      } else {
        console.warn(prefix, message);
      }
    },
    error(message, meta) {
      if (meta) {
        console.error(prefix, message, JSON.stringify(meta));
      } else {
        console.error(prefix, message);
      }
    },
  };
}

module.exports = { createLogger };
