
class JsonExtractor {

    async extract(page) {

        const title =
            await this.extractTitle(page);

        const menus =
            await this.extractMenus(page);

        const buttons =
            await this.extractButtons(page);

        return {
            title,
            menus,
            buttons
        };
    }

    async extractTitle(page) {

        return await page.title();
    }

    async extractMenus(page) {

        return await page.$$eval(
            "a",
            elements =>
                elements.map(
                    e => e.innerText
                )
        );
    }

    async extractButtons(page) {

        return await page.$$eval(
            "button",
            elements =>
                elements.map(
                    e => e.innerText
                )
        );
    }

}

module.exports = new JsonExtractor();