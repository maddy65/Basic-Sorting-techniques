const path = require('node:path');
const { analyzeRuntime } = require('./playwright-runtime-analyzer');

async function main() {
  const [appUrl] = process.argv.slice(2);
  const outputDir = path.join(process.cwd(), 'reports');
  const result = await analyzeRuntime({ appUrl, outputDir });
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
