const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const { createLogger } = require('../../utils/logger');

function normalizeText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function slugify(value) {
  return normalizeText(value || 'page')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'page';
}

async function analyzeRuntime({ appUrl, outputDir, maxPages = 25, logger = createLogger('runtime') } = {}) {
  if (!appUrl) {
    return [];
  }

  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  const runtimePages = [];
  const queue = [appUrl];
  const visited = new Set();
  const screenshotDir = path.join(outputDir, 'screenshots');

  fs.mkdirSync(screenshotDir, { recursive: true });

  while (queue.length > 0 && runtimePages.length < maxPages) {
    const currentUrl = queue.shift();
    if (!currentUrl || visited.has(currentUrl)) continue;
    visited.add(currentUrl);

    const pageRequests = [];
    const pageResponses = [];
    const requestHandler = (request) => pageRequests.push({ method: request.method(), url: request.url() });
    const responseHandler = (response) => pageResponses.push({ status: response.status(), url: response.url() });

    page.on('request', requestHandler);
    page.on('response', responseHandler);

    try {
      await page.goto(currentUrl, { waitUntil: 'domcontentloaded', timeout: 20000 });
      const pageData = await page.evaluate(() => {
        const normaliseText = (value) => (value || '').replace(/\s+/g, ' ').trim();
        const links = Array.from(document.querySelectorAll('a[href], button, input[type="submit"], [role="button"], summary'))
          .slice(0, 25)
          .map((element) => ({
            text: normaliseText(element.textContent || element.getAttribute('aria-label') || ''),
            href: element.getAttribute('href') || '',
          }));

        const forms = Array.from(document.querySelectorAll('form'))
          .slice(0, 10)
          .map((form) => ({
            action: form.getAttribute('action') || '',
            id: form.getAttribute('id') || '',
            labels: Array.from(form.querySelectorAll('label, input, textarea, select'))
              .slice(0, 8)
              .map((element) => normaliseText(element.getAttribute('aria-label') || element.getAttribute('placeholder') || element.textContent || ''))
              .filter(Boolean),
          }));

        const tables = Array.from(document.querySelectorAll('table'))
          .slice(0, 8)
          .map((table) => ({ rows: table.rows.length, id: table.getAttribute('id') || '' }));

        const menus = Array.from(document.querySelectorAll('nav, [role="navigation"], ul, ol'))
          .slice(0, 10)
          .map((element) => normaliseText(element.textContent || ''));

        const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6'))
          .slice(0, 20)
          .map((element) => normaliseText(element.textContent || ''))
          .filter(Boolean);

        const text = normaliseText(document.body ? document.body.innerText : '');
        const metaDescription = normaliseText(document.querySelector('meta[name="description"]')?.getAttribute('content') || '');

        return { title: document.title, metaDescription, headings, text, links, forms, tables, menus };
      });

      const pathname = new URL(currentUrl).pathname.replace(/\/+$/, '') || '/';
      const screenshotPath = path.join(screenshotDir, `${slugify(pathname)}-${runtimePages.length + 1}.png`);
      await page.screenshot({ path: screenshotPath, fullPage: true });

      runtimePages.push({
        url: currentUrl,
        title: pageData?.title || 'Unavailable',
        metaDescription: pageData?.metaDescription || '',
        headings: pageData?.headings || [],
        text: pageData?.text || '',
        links: pageData?.links || [],
        forms: pageData?.forms || [],
        tables: pageData?.tables || [],
        menus: pageData?.menus || [],
        screenshotPath,
        networkRequests: pageRequests.slice(0, 20),
        networkResponses: pageResponses.slice(0, 20),
      });

      logger.info(`Crawled ${currentUrl}`);

      const internalLinks = (pageData?.links || [])
        .map((entry) => entry.href)
        .filter((href) => href && !href.startsWith('mailto:') && !href.startsWith('tel:') && !href.startsWith('javascript:'));

      internalLinks.forEach((href) => {
        try {
          const absoluteUrl = new URL(href, currentUrl).toString();
          if (absoluteUrl.startsWith(new URL(currentUrl).origin) && !visited.has(absoluteUrl) && !queue.includes(absoluteUrl)) {
            queue.push(absoluteUrl);
          }
        } catch (error) {
          // ignore invalid URLs
        }
      });
    } catch (error) {
      logger.warn(`Failed to crawl ${currentUrl}`, { message: error.message });
      runtimePages.push({
        url: currentUrl,
        title: 'Unavailable',
        headings: [],
        text: '',
        links: [],
        forms: [],
        tables: [],
        menus: [],
        screenshotPath: null,
        networkRequests: pageRequests.slice(0, 20),
        networkResponses: pageResponses.slice(0, 20),
      });
    } finally {
      page.removeListener('request', requestHandler);
      page.removeListener('response', responseHandler);
    }
  }

  await browser.close();
  return runtimePages;
}

module.exports = { analyzeRuntime };
