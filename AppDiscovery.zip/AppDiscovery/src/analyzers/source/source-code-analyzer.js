const fs = require('node:fs');
const path = require('node:path');
const { createLogger } = require('../../utils/logger');

function toTitleCase(value) {
  return String(value || '')
    .replace(/[-_./]+/g, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

async function collectFiles(rootPath, { maxFiles = 20000, logger = createLogger('source') } = {}) {
  const results = [];
  if (!rootPath || !fs.existsSync(rootPath)) return results;

  const stack = [rootPath];
  const validExtensions = new Set(['.cs', '.vb', '.ts', '.tsx', '.js', '.jsx', '.json', '.yml', '.yaml', '.sql', '.md', '.aspx', '.ascx', '.cshtml', '.razor', '.html', '.css']);
  const skippedDirectories = new Set(['node_modules', '.git', 'dist', 'build', 'bin', 'obj', '.next', '.turbo']);

  while (stack.length > 0 && results.length < maxFiles) {
    const current = stack.pop();
    const stat = await fs.promises.stat(current);
    if (!stat.isDirectory()) {
      if (validExtensions.has(path.extname(current).toLowerCase())) {
        results.push(current);
      }
      continue;
    }

    const entries = await fs.promises.readdir(current, { withFileTypes: true });
    const directories = [];
    for (const entry of entries) {
      const candidate = path.join(current, entry.name);
      if (entry.isDirectory()) {
        if (!skippedDirectories.has(entry.name)) {
          directories.push(candidate);
        }
      } else if (entry.isFile() && validExtensions.has(path.extname(entry.name).toLowerCase())) {
        results.push(candidate);
      }
    }
    stack.push(...directories.reverse());
  }

  logger.info(`Discovered ${results.length} source files`, { rootPath });
  return results;
}

function analyzeSourceFiles(files) {
  const controllers = [];
  const services = [];
  const repositories = [];
  const entities = [];
  const dtos = [];
  const apis = [];
  const databaseTables = [];
  const validationRules = [];
  const integrations = [];
  const businessFeatures = [];

  files.forEach((file) => {
    const content = file.content || '';
    const normalizedPath = file.path.replace(/\\/g, '/');
    const displayName = path.basename(normalizedPath);
    const logicalName = displayName.replace(/\.(cs|ts|js|tsx|jsx|vb|aspx|ascx|cshtml|razor|md|json|sql)$/i, '');

    if (/controller/i.test(normalizedPath) || /controller/i.test(displayName) || /^frm/i.test(logicalName) || /Form$/i.test(logicalName)) {
      controllers.push({ name: logicalName, path: normalizedPath });
    }
    if (/service/i.test(normalizedPath) || /service/i.test(displayName) || /BLL$/i.test(logicalName)) {
      services.push({ name: logicalName, path: normalizedPath });
    }
    if (/repository|repo/i.test(normalizedPath) || /repository|repo/i.test(displayName) || /DAL$/i.test(logicalName)) {
      repositories.push({ name: logicalName, path: normalizedPath });
    }
    if (/entities?|model/i.test(normalizedPath) || /entities?|model/i.test(displayName)) {
      entities.push({ name: logicalName, path: normalizedPath });
    }
    if (/dtos?|viewmodel|view-model/i.test(normalizedPath) || /dtos?|viewmodel|view-model/i.test(displayName)) {
      dtos.push({ name: logicalName, path: normalizedPath });
    }

    const apiMatches = [...content.matchAll(/\[(HttpGet|HttpPost|HttpPut|HttpDelete|Route|MapGet|MapPost|MapPut|MapDelete)\s*\(([^)]*)\)/g)];
    apiMatches.forEach((match) => {
      const rawPath = match[2].replace(/["']/g, '').trim();
      if (rawPath) {
        apis.push({ verb: match[1], path: rawPath, source: normalizedPath });
      }
    });

    const expressMatches = [...content.matchAll(/(app|router)\.(get|post|put|delete|patch)\s*\(\s*['"]([^'"]+)['"]/g)];
    expressMatches.forEach((match) => {
      apis.push({ verb: match[2].toUpperCase(), path: match[3], source: normalizedPath });
    });

    const routeMatches = [...content.matchAll(/@Route\(["']([^"']+)["']\)/g)];
    routeMatches.forEach((match) => apis.push({ verb: 'ROUTE', path: match[1], source: normalizedPath }));

    const sqlTableMatches = [...content.matchAll(/create\s+table\s+([a-zA-Z0-9_]+)/gi)];
    sqlTableMatches.forEach((match) => databaseTables.push(match[1].toLowerCase()));

    const dbSetMatches = [...content.matchAll(/DbSet<([A-Za-z0-9_]+)>/g)];
    dbSetMatches.forEach((match) => entities.push({ name: match[1], path: normalizedPath }));

    const validationMatch = [...content.matchAll(/\[(Required|Range|StringLength|RegularExpression|EmailAddress|MinLength|MaxLength)[^\]]*\]/g)];
    validationMatch.forEach((match) => validationRules.push({ rule: match[0], source: normalizedPath }));

    const integrationMatches = [...content.matchAll(/(HttpClient|axios|fetch|RestSharp|SendGrid|S3|Azure|Kafka|Rabbit|Redis|SqlConnection|MongoClient|Stripe|PayPal|SMTP)/g)];
    integrationMatches.forEach((match) => {
      const name = match[1] === 'HttpClient' ? logicalName : match[1];
      if (!integrations.some((entry) => entry.name === name)) {
        integrations.push({ name, source: normalizedPath });
      }
    });
  });

  const featureNames = new Set();
  controllers.forEach((entry) => featureNames.add(entry.name.replace(/Controller$/i, '')));
  services.forEach((entry) => featureNames.add(entry.name.replace(/Service$/i, '')));
  apis.forEach((entry) => featureNames.add(entry.path.replace(/^\//, '').split('/')[0] || 'core'));
  featureNames.forEach((name) => businessFeatures.push({ name: toTitleCase(name), evidence: [] }));

  return {
    controllers,
    services,
    repositories,
    entities,
    dtos,
    apis,
    databaseTables: [...new Set(databaseTables)],
    validationRules,
    integrations,
    businessFeatures,
  };
}

async function analyzeSource({ frontendPath, backendPath, logger = createLogger('source') }) {
  const frontendFiles = await collectFiles(frontendPath, { logger });
  const backendFiles = await collectFiles(backendPath, { logger });
  const combinedFiles = [
    ...frontendFiles.map((filePath) => ({ path: filePath, content: fs.readFileSync(filePath, 'utf8') })),
    ...backendFiles.map((filePath) => ({ path: filePath, content: fs.readFileSync(filePath, 'utf8') })),
  ];

  const analysis = analyzeSourceFiles(combinedFiles);
  // attach raw files so downstream stages (call-graph inference) can inspect bodies
  analysis.files = combinedFiles;
  return analysis;
}

function inferCallGraphFromAnalysis(analysis) {
  // heuristic: infer a call graph from classes, field declarations, and method invocations
  const files = (analysis && analysis.files) || [];
  const nodes = new Set();
  const edges = [];

  const knownClasses = new Set(files.map((file) => path.basename(file.path).replace(/\.(cs|ts|js|tsx|jsx|vb|aspx|ascx|cshtml|razor|md|json|sql)$/i, '')).filter(Boolean));
  const classType = new Map();

  function getTypeForClass(className) {
    if (/BLL$/i.test(className)) return 'Service';
    if (/DAL$/i.test(className) || /Repository$/i.test(className)) return 'Repository';
    if (/Controller$/i.test(className) || /^frm/i.test(className) || /Form$/i.test(className)) return 'Controller';
    if (/View$/i.test(className) || /Page$/i.test(className)) return 'View';
    return 'Component';
  }

  knownClasses.forEach((className) => {
    classType.set(className, getTypeForClass(className));
  });

  function addNode(name, type) {
    const id = `${type}:${name}`;
    nodes.add(JSON.stringify({ id, name, type }));
    return id;
  }

  for (const file of files) {
    const content = file.content || '';
    const base = path.basename(file.path).replace(/\.(cs|ts|js|tsx|jsx|vb|aspx|ascx|cshtml|razor|md|json|sql)$/i, '');
    const className = base;
    const fromType = classType.get(className) || getTypeForClass(className);
    const fromId = addNode(className, fromType);

    const variableMap = new Map();

    // field and variable declarations pointing to known types
    const declarationRegex = /(?:private|protected|public|internal)?\s*(?:readonly\s+)?([A-Za-z0-9_<>]+)\s+(_?[A-Za-z0-9_]+)\s*(?:=|;)/g;
    let declMatch;
    while ((declMatch = declarationRegex.exec(content)) !== null) {
      const declaredType = declMatch[1].replace(/<.*>$/,'');
      const varName = declMatch[2];
      if (knownClasses.has(declaredType)) {
        variableMap.set(varName, declaredType);
      }
    }

    const newRegex = /(?:var|[A-Za-z0-9_<>]+)\s+(_?[A-Za-z0-9_]+)\s*=\s*new\s+([A-Za-z0-9_<>]+)\s*\(/g;
    let newMatch;
    while ((newMatch = newRegex.exec(content)) !== null) {
      const varName = newMatch[1];
      const createdType = newMatch[2].replace(/<.*>$/,'');
      if (knownClasses.has(createdType)) {
        variableMap.set(varName, createdType);
      }
    }

    const invocationRegex = /([A-Za-z0-9_]+)\s*\.\s*([A-Za-z0-9_]+)\s*\(/g;
    let m;
    while ((m = invocationRegex.exec(content)) !== null) {
      const caller = m[1];
      const calleeMethod = m[2];
      const targetClass = variableMap.get(caller) || (knownClasses.has(caller) ? caller : null);
      if (!targetClass) continue;
      if (/Attribute$/i.test(calleeMethod)) continue;
      const toType = classType.get(targetClass) || getTypeForClass(targetClass);
      const toId = addNode(targetClass, toType);
      edges.push({ from: fromId, to: toId, via: calleeMethod });
    }

    const directNewRegex = /new\s+([A-Za-z0-9_<>]+)\s*\(/g;
    let directMatch;
    while ((directMatch = directNewRegex.exec(content)) !== null) {
      const targetClass = directMatch[1].replace(/<.*>$/,'');
      if (!knownClasses.has(targetClass)) continue;
      if (targetClass === className) continue;
      const toType = classType.get(targetClass) || getTypeForClass(targetClass);
      const toId = addNode(targetClass, toType);
      edges.push({ from: fromId, to: toId, via: 'new ' + targetClass });
    }
  }

  return {
    nodes: Array.from(nodes).map((s) => JSON.parse(s)),
    edges,
  };
}

module.exports = { analyzeSource, analyzeSourceFiles, collectFiles, inferCallGraphFromAnalysis };
