const path = require('node:path');
const { analyzeSource } = require('./source-code-analyzer');

async function main() {
  const [frontendPath, backendPath] = process.argv.slice(2);
  const result = await analyzeSource({ frontendPath, backendPath });
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
