function toGraphId(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'node';
}

function buildCanonicalGraph(runtimeData, sourceAnalysis) {
  const nodes = [];
  const edges = [];

  const addNode = (node) => {
    if (!nodes.some((entry) => entry.id === node.id)) {
      nodes.push(node);
    }
  };

  const addEdge = (source, target, kind, metadata = {}) => {
    const id = `${source}-${target}-${kind}`;
    if (!edges.some((entry) => entry.id === id)) {
      edges.push({ id, source, target, kind, ...metadata });
    }
  };

  addNode({ id: 'runtime-root', type: 'runtime-root', label: 'Runtime Root' });

  runtimeData.forEach((page, index) => {
    const pageNodeId = `runtime-page-${index + 1}`;
    addNode({ id: pageNodeId, type: 'runtime-page', label: page.title || page.url, metadata: { url: page.url } });
    addEdge('runtime-root', pageNodeId, 'contains');
  });

  if (sourceAnalysis.controllers.length > 0) {
    sourceAnalysis.controllers.forEach((controller, index) => {
      const controllerNodeId = `controller-${toGraphId(controller.name || `controller-${index + 1}`)}`;
      addNode({ id: controllerNodeId, type: 'controller', label: controller.name, metadata: { path: controller.path } });
      runtimeData.forEach((_, runtimeIndex) => {
        const runtimeNodeId = `runtime-page-${runtimeIndex + 1}`;
        addEdge(runtimeNodeId, controllerNodeId, 'runtime-to-controller');
      });
    });
  }

  if (sourceAnalysis.services.length > 0) {
    sourceAnalysis.services.forEach((service, index) => {
      const serviceNodeId = `service-${toGraphId(service.name || `service-${index + 1}`)}`;
      addNode({ id: serviceNodeId, type: 'service', label: service.name, metadata: { path: service.path } });
      const controllerNodeId = sourceAnalysis.controllers[0]
        ? `controller-${toGraphId(sourceAnalysis.controllers[0].name)}`
        : null;
      if (controllerNodeId) {
        addEdge(controllerNodeId, serviceNodeId, 'controller-to-service');
      }
    });
  }

  if (sourceAnalysis.apis.length > 0) {
    sourceAnalysis.apis.forEach((api, index) => {
      const apiNodeId = `api-${index + 1}`;
      addNode({ id: apiNodeId, type: 'api', label: `${api.verb} ${api.path}`, metadata: { source: api.source } });
      const controllerNodeId = sourceAnalysis.controllers[0]
        ? `controller-${toGraphId(sourceAnalysis.controllers[0].name)}`
        : null;
      if (controllerNodeId) {
        addEdge(controllerNodeId, apiNodeId, 'exposes');
      }
    });
  }

  return { nodes, edges };
}

module.exports = { buildCanonicalGraph };
