const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const { createLogger } = require('../utils/logger');

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function normalizeText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function buildExecutiveNarrative(runtimeData, sourceAnalysis) {
  const pageCount = runtimeData.length;
  const discoveredRoutes = runtimeData.map((page) => page.url).slice(0, 5).join(', ');
  const codeSignal = sourceAnalysis.controllers.length + sourceAnalysis.services.length + sourceAnalysis.repositories.length + sourceAnalysis.entities.length + sourceAnalysis.apis.length;

  if (codeSignal === 0) {
    return `The crawl suggests a small presentation-focused site with ${pageCount} discovered page(s). The available source paths did not expose a recognizable local backend implementation.`;
  }

  return `The crawl surfaced ${pageCount} page(s) and ${sourceAnalysis.apis.length} API endpoint(s), indicating a layered application with both runtime navigation and local source structure. The discovered controllers, services, and repositories suggest a modular enterprise-style implementation.`;
}

function buildPageInventory(runtimeData) {
  return (runtimeData || []).map((page) => {
    const title = normalizeText(page.title || page.url || 'Page');
    const route = new URL(page.url).pathname.replace(/\/+$/, '') || '/';
    return `<li><strong>${escapeHtml(title)}</strong> — ${escapeHtml(route)}</li>`;
  }).join('');
}

function buildBusinessReport(runtimeData, sourceAnalysis, graph, executiveNarrative) {
  const title = 'Business Analysis Report';
  const inventory = buildPageInventory(runtimeData);
  const useCaseList = sourceAnalysis.businessFeatures.length > 0
    ? sourceAnalysis.businessFeatures.map((feature) => `<li>${escapeHtml(feature.name)}</li>`).join('')
    : '<li>No business feature names were inferred from the supplied source paths.</li>';
  const mermaid = `graph TD\nA[Visitor] --> B[Primary Workflow]\nB --> C[Inquiry or Purchase]\nC --> D[Support or Review]`;

  return `<!doctype html><html><head><meta charset="utf-8" /><title>${title}</title><style>body{font-family:Arial,sans-serif;line-height:1.5;padding:24px;color:#132238;}h1,h2{color:#0f4c81;}section{margin-bottom:20px;}pre{background:#f6f8fb;padding:14px;border-radius:8px;overflow:auto;}</style></head><body><h1>${title}</h1><section><h2>Executive Summary</h2><p>${escapeHtml(executiveNarrative)}</p></section><section><h2>Runtime Inventory</h2><ul>${inventory}</ul></section><section><h2>Business Features</h2><ul>${useCaseList}</ul></section><section><h2>Canonical Graph Snapshot</h2><ul>${graph.nodes.map((node) => `<li>${escapeHtml(node.label)} (${escapeHtml(node.type)})</li>`).join('')}</ul></section><section><h2>Mermaid Architecture</h2><pre class="mermaid">${mermaid}</pre></section></body></html>`;
}

function buildTechnicalReport(runtimeData, sourceAnalysis, graph, executiveNarrative) {
  const title = 'Technical Analysis Report';
  const inventory = buildPageInventory(runtimeData);
  let sequence = `sequenceDiagram\nparticipant Client\nparticipant Controller\nparticipant Service\nparticipant Repository\nparticipant Database\nClient->>Controller: Request action\nController->>Service: Execute workflow\nService->>Repository: Read or persist data\nRepository->>Database: Query or update`;
  const architecture = `graph TD\nA[Runtime Pages] --> B[Controller]\nB --> C[Service]\nC --> D[Repository]\nD --> E[Database]`;

  // if a call graph was attached to the canonical graph, synthesize a sequence diagram from edges
  try {
    if (graph && graph.callGraph && Array.isArray(graph.callGraph.edges) && graph.callGraph.edges.length > 0) {
      const participants = new Set(['Client']);
      const lines = ['sequenceDiagram'];

      // register participants from nodes
      (graph.callGraph.nodes || []).forEach((n) => participants.add(n.name));

      participants.forEach((p) => lines.push(`participant ${p}`));

      // create interactions from edges: map ids like "Service:Name" to the Name label
      (graph.callGraph.edges || []).forEach((e) => {
        const fromLabel = (e.from || '').split(':').slice(1).join(':') || e.from;
        const toLabel = (e.to || '').split(':').slice(1).join(':') || e.to;
        const via = e.via || '';
        lines.push(`${fromLabel}-->>${toLabel}: ${via}`);
      });

      sequence = lines.join('\n');
    }
  } catch (err) {
    // fall back to generic sequence
  }

  return `<!doctype html><html><head><meta charset="utf-8" /><title>${title}</title><style>body{font-family:Arial,sans-serif;line-height:1.5;padding:24px;color:#132238;}h1,h2{color:#0b5fff;}section{margin-bottom:20px;}pre{background:#f6f8fb;padding:14px;border-radius:8px;overflow:auto;}</style></head><body><h1>${title}</h1><section><h2>Executive Summary</h2><p>${escapeHtml(executiveNarrative)}</p></section><section><h2>Runtime Inventory</h2><ul>${inventory}</ul></section><section><h2>Source Signals</h2><ul><li>Controllers: ${sourceAnalysis.controllers.map((entry) => entry.name).join(', ') || 'None detected'}</li><li>Services: ${sourceAnalysis.services.map((entry) => entry.name).join(', ') || 'None detected'}</li><li>Repositories: ${sourceAnalysis.repositories.map((entry) => entry.name).join(', ') || 'None detected'}</li><li>APIs: ${sourceAnalysis.apis.map((entry) => `${entry.verb} ${entry.path}`).join(', ') || 'None detected'}</li></ul></section><section><h2>Mermaid Sequence Diagram</h2><pre class="mermaid">${sequence}</pre></section><section><h2>Mermaid Architecture Diagram</h2><pre class="mermaid">${architecture}</pre></section><section><h2>Canonical Graph</h2><pre>${escapeHtml(JSON.stringify(graph, null, 2))}</pre></section></body></html>`;
}

async function writeReports(runtimeData, sourceAnalysis, graph, outputDir, logger = createLogger('reports')) {
  fs.mkdirSync(outputDir, { recursive: true });
  fs.mkdirSync(path.join(outputDir, 'screenshots'), { recursive: true });

  const executiveNarrative = buildExecutiveNarrative(runtimeData, sourceAnalysis);
  const businessHtml = buildBusinessReport(runtimeData, sourceAnalysis, graph, executiveNarrative);
  const technicalHtml = buildTechnicalReport(runtimeData, sourceAnalysis, graph, executiveNarrative);

  const businessPath = path.join(outputDir, 'business-analysis.html');
  const technicalPath = path.join(outputDir, 'technical-analysis.html');
  const businessPdfPath = path.join(outputDir, 'business-analysis.pdf');
  const technicalPdfPath = path.join(outputDir, 'technical-analysis.pdf');
  const discoveryJsonPath = path.join(outputDir, 'discovery.json');
  const graphJsonPath = path.join(outputDir, 'graph.json');
  const summaryJsonPath = path.join(outputDir, 'summary.json');

  fs.writeFileSync(businessPath, businessHtml, 'utf8');
  fs.writeFileSync(technicalPath, technicalHtml, 'utf8');
  fs.writeFileSync(discoveryJsonPath, JSON.stringify({ runtimeData, sourceAnalysis, executiveNarrative }, null, 2), 'utf8');
  fs.writeFileSync(graphJsonPath, JSON.stringify(graph, null, 2), 'utf8');
  fs.writeFileSync(summaryJsonPath, JSON.stringify({ runtimePages: runtimeData.length, sourceSignals: { controllers: sourceAnalysis.controllers.length, services: sourceAnalysis.services.length, repositories: sourceAnalysis.repositories.length, apis: sourceAnalysis.apis.length }, graph: { nodes: graph.nodes.length, edges: graph.edges.length } }, null, 2), 'utf8');

  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.setContent(businessHtml, { waitUntil: 'domcontentloaded' });
  await page.pdf({ path: businessPdfPath, format: 'A4', printBackground: true });
  await page.setContent(technicalHtml, { waitUntil: 'domcontentloaded' });
  await page.pdf({ path: technicalPdfPath, format: 'A4', printBackground: true });
  await browser.close();

  logger.info('Wrote reports', { businessPath, technicalPath, discoveryJsonPath, graphJsonPath });

  return {
    businessHtmlPath: businessPath,
    technicalHtmlPath: technicalPath,
    businessPdfPath,
    technicalPdfPath,
    discoveryJsonPath,
    graphJsonPath,
    summaryJsonPath,
  };
}

module.exports = { writeReports, buildExecutiveNarrative };
