const { chromium } = require("playwright");
const MAX_PAGES = 50;
async function crawl(startUrl) {
    const browser = await chromium.launch({
        headless: true
    });
    const context = await browser.newContext();
    const page = await context.newPage();
    const visited = new Set();
    const queue = [startUrl];
    const results = [];
    const baseHost = new URL(startUrl).host;
    while (queue.length > 0 && visited.size < MAX_PAGES) {
        const currentUrl = queue.shift();
        if (visited.has(currentUrl)) {
            continue;
        }
        try {
            console.log(`Visiting ${currentUrl}`);
            await page.goto(currentUrl, {
                waitUntil: "networkidle",
                timeout: 30000
            });
            visited.add(currentUrl);
            const pageInfo = await page.evaluate(() => {
                const title = document.title || "Untitled";
                const links =
                    Array.from(
                        document.querySelectorAll("a[href]")
                    ).map(x => x.href);
                const buttons =
                    Array.from(
                        document.querySelectorAll(
                            "button,input[type='button'],input[type='submit']"
                        )
                    ).map(x => x.innerText || x.value);
                const forms =
                    Array.from(
                        document.querySelectorAll("form")
                    ).map((_, index) => `Form ${index + 1}`);
                const tables =
                    Array.from(
                        document.querySelectorAll("table")
                    ).map((_, index) => `Table ${index + 1}`);
                const menus =
                    Array.from(
                        document.querySelectorAll(
                            "nav a,.menu a,.navbar a"
                        )
                    ).map(x => x.innerText);

                return {
                    title,
                    links,
                    buttons,
                    forms,
                    tables,
                    menus
                };
            });

            results.push({
                url: currentUrl,
                title: pageInfo.title,
                buttons: pageInfo.buttons,
                forms: pageInfo.forms,
                tables: pageInfo.tables,
                menus: pageInfo.menus
            });

            pageInfo.links.forEach(link => {

                try {

                    const parsed =
                        new URL(link);

                    if (
                        parsed.host === baseHost &&
                        !visited.has(link)
                    ) {
                        queue.push(link);
                    }

                } catch {
                    // Ignore invalid URLs
                }

            });

        } catch (error) {

            console.log(
                `Failed ${currentUrl}`,
                error.message
            );

        }

    }

    await browser.close();

    return results;
}

module.exports = {
    crawl
};