# Local Reverse Engineering Assistant

This project is a local Node.js application that helps reverse engineer a legacy web application.

## What it does

- Accepts a web application URL and optionally frontend and backend source folders.
- Crawls the running application to discover pages, menus, buttons, forms, tables and basic navigation.
- Scans source files for controllers, services, repositories, entities, APIs, DTOs, database tables, validation rules and integrations when source folders are provided.
- Generates two local PDF reports:
  - Business Analysis Report
  - Technical Analysis Report

## Run locally

1. Install dependencies:
   - `npm install`
   - `npx playwright install chromium`
2. Start the app:
   - `npm start`
3. Open `http://localhost:3000`
4. Enter the application URL. The source paths are optional. You can test a live website with just the URL, or add source folders for deeper analysis.

## Verification

The project includes a unit test for the source-analysis parser:

- `npm test`
