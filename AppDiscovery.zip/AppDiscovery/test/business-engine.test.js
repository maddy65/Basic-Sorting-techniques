const test = require('node:test');
const assert = require('node:assert/strict');
const { buildCanonicalGraph } = require('../src/business-engine/business-engine');

test('buildCanonicalGraph creates runtime and source nodes and edges', () => {
  const runtimeData = [
    {
      url: 'https://example.com/',
      title: 'Home',
      headings: ['Welcome'],
      links: [{ text: 'Contact', href: '/contact' }],
      forms: [],
      text: 'Welcome to the product.',
    },
  ];

  const sourceAnalysis = {
    controllers: [{ name: 'HomeController', path: '/src/HomeController.cs' }],
    services: [{ name: 'HomeService', path: '/src/HomeService.cs' }],
    repositories: [{ name: 'HomeRepository', path: '/src/HomeRepository.cs' }],
    entities: [{ name: 'HomeEntity', path: '/src/HomeEntity.cs' }],
    apis: [{ verb: 'GET', path: '/home', source: '/src/HomeController.cs' }],
    databaseTables: ['home'],
    validations: [],
    integrations: [],
    businessFeatures: [],
  };

  const graph = buildCanonicalGraph(runtimeData, sourceAnalysis);

  assert.ok(graph.nodes.length >= 4);
  assert.ok(graph.edges.some((edge) => edge.source.includes('runtime') && edge.target.includes('controller')));
  assert.ok(graph.edges.some((edge) => edge.source.includes('controller') && edge.target.includes('service')));
  assert.ok(graph.nodes.some((node) => node.id.includes('runtime-page')));
});
