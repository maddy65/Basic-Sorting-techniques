const test = require('node:test');
const assert = require('node:assert/strict');
const { analyzeSourceFiles, buildBusinessUseCases } = require('../src/api/analysis');

test('detects controllers, services, repositories, entities, apis, dto and database tables', () => {
  const files = [
    {
      path: 'Controllers/UserController.cs',
      content: 'public class UserController { [HttpGet("/users")] public IActionResult GetUsers() { return Ok(); } }'
    },
    {
      path: 'Services/UserService.cs',
      content: 'public class UserService { public string Run() => "ok"; }'
    },
    {
      path: 'Repositories/UserRepository.cs',
      content: 'public class UserRepository { }'
    },
    {
      path: 'Entities/User.cs',
      content: 'public class User { public string Name { get; set; } }'
    },
    {
      path: 'Dtos/UserDto.cs',
      content: 'public class UserDto { public string Name { get; set; } }'
    },
    {
      path: 'Database/schema.sql',
      content: 'CREATE TABLE users (id INT PRIMARY KEY, name VARCHAR(100));'
    },
    {
      path: 'Validation/CustomerValidator.cs',
      content: '[Required] public string Name { get; set; }'
    },
    {
      path: 'Integrations/EmailClient.cs',
      content: 'HttpClient httpClient = new HttpClient();'
    }
  ];

  const result = analyzeSourceFiles(files);

  assert.ok(result.controllers.some((entry) => entry.name.includes('UserController')));
  assert.ok(result.services.some((entry) => entry.name.includes('UserService')));
  assert.ok(result.repositories.some((entry) => entry.name.includes('UserRepository')));
  assert.ok(result.entities.some((entry) => entry.name.includes('User')));
  assert.ok(result.dtos.some((entry) => entry.name.includes('UserDto')));
  assert.ok(result.databaseTables.includes('users'));
  assert.ok(result.validationRules.some((entry) => entry.rule.includes('Required')));
  assert.ok(result.integrations.some((entry) => entry.name.includes('EmailClient')));
  assert.ok(result.apis.some((entry) => entry.path.includes('/users')));
});

test('buildBusinessUseCases derives app-wide business flows from combined page content', () => {
  const runtimeData = [
    {
      url: 'https://example.com',
      title: 'Home Page',
      headings: ['Shop Online', 'Featured Products'],
      links: [{ text: 'Shop Now', href: '/products' }],
      forms: [],
      text: 'Browse products and explore the catalog.'
    },
    {
      url: 'https://example.com/contact',
      title: 'Contact Page',
      headings: ['Contact Us'],
      links: [{ text: 'Get in touch', href: '/contact' }],
      forms: [{ action: '/contact', labels: ['Name', 'Email'] }],
      text: 'Please contact the team for support or a quote.'
    },
    {
      url: 'https://example.com/about',
      title: 'About Page',
      headings: ['About Us', 'Our Story'],
      links: [{ text: 'Meet the team', href: '/about' }],
      forms: [],
      text: 'Learn about the company, mission and portfolio.'
    },
    {
      url: 'https://example.com/blog',
      title: 'Blog Page',
      headings: ['Latest Articles'],
      links: [{ text: 'Read article', href: '/blog/post' }],
      forms: [],
      text: 'Read articles, resources and educational guides.'
    },
    {
      url: 'https://example.com/pricing',
      title: 'Pricing Page',
      headings: ['Pricing Plans'],
      links: [{ text: 'Choose plan', href: '/pricing' }],
      forms: [],
      text: 'Compare plans and pricing for each product.'
    },
    {
      url: 'https://example.com/account',
      title: 'Account Page',
      headings: ['Sign In'],
      links: [{ text: 'Create account', href: '/account' }],
      forms: [{ action: '/account', labels: ['Email', 'Password'] }],
      text: 'Sign in or register to manage your account.'
    }
  ];

  const useCases = buildBusinessUseCases(runtimeData);
  const shopUseCase = useCases.find((entry) => entry.goal.toLowerCase().includes('shop'));
  const contactUseCase = useCases.find((entry) => entry.goal.toLowerCase().includes('contact'));

  assert.ok(useCases.length >= 6);
  assert.ok(shopUseCase);
  assert.ok(contactUseCase);
  assert.equal(shopUseCase.scope, 'application');
  assert.equal(contactUseCase.scope, 'application');
  assert.ok(shopUseCase.evidence.some((item) => item.includes('Home Page')));
  assert.ok(contactUseCase.evidence.some((item) => item.includes('Contact Page')));
  assert.ok(shopUseCase.evidence.length >= 2);
});

test('buildBusinessUseCases infers use cases from runtime page vocabulary', () => {
  const runtimeData = [
    {
      url: 'https://example.com/trial',
      title: 'Start Your Free Trial',
      headings: ['Try It Today'],
      links: [{ text: 'Start free trial', href: '/trial' }],
      forms: [],
      text: 'Begin a free trial and evaluate the platform.'
    },
    {
      url: 'https://example.com/learn',
      title: 'Learn More',
      headings: ['Watch a demo'],
      links: [{ text: 'Schedule a demo', href: '/demo' }],
      forms: [],
      text: 'View product walkthroughs and schedule a demo.'
    }
  ];

  const useCases = buildBusinessUseCases(runtimeData);
  const trialUseCase = useCases.find((entry) => entry.goal.toLowerCase().includes('trial'));
  const demoUseCase = useCases.find((entry) => entry.goal.toLowerCase().includes('demo'));

  assert.ok(trialUseCase);
  assert.ok(demoUseCase);
  assert.ok(trialUseCase.evidence.some((item) => item.includes('Start Your Free Trial')));
  assert.ok(demoUseCase.evidence.some((item) => item.includes('Learn More')));
});
